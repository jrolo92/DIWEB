# Mejoras:
- Modificar catálogo (version móvil) para que los botones de pedir esten centrados.