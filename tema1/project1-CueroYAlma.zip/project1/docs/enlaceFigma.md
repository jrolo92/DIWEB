# Enlace Figma - Cuero & Alma

[Accede a nuestro proyecto Figma](https://www.figma.com/design/jArjVMoC13AiIvKLTvLWdn/Sin-t%C3%ADtulo?node-id=0-1&p=f&t=rKOY1gKGhC1Cz7RA-0)

## Autores
- Yohel Gómez Benítez
- Jaime Gómez Mesa
- Javier Rodríguez López